// Sample Hairdresser Data
const appointmentsData: Hairdresser[] = [
    {
        id: 0,
        name: "Fodrász Fruzsi",
        title: "Mesterfodrász",
        description: "20 éves tapasztalattal és modern stílusérzékkel rendelkező fodrász.",
        workingHours: [
            { day: "Hétfő", dayIndex: 1, start: "10:00", end: "15:30" },
            { day: "Szerda", dayIndex: 3, start: "09:00", end: "14:30" },
            { day: "Szombat", dayIndex: 6, start: "10:00", end: "13:00" },
        ],
        bookings: [
            { date: "2024-11-16", time: "10:00", clientName: "János", status: "booked" },
            { date: "2024-11-17", time: "11:00", clientName: "Katalin", status: "available" }
        ],
    },
    {
        id: 1,
        name: "Fodrász Bence",
        title: "Stílustanácsadó és fodrász",
        description: "A legújabb trendekkel, férfi és női hajvágások specialistája.",
        workingHours: [
            { day: "Kedd", dayIndex: 2, start: "11:00", end: "18:00" },
            { day: "Csütörtök", dayIndex: 4, start: "10:00", end: "16:00" },
        ],
        bookings: [
            { date: "2024-11-10", time: "10:00", clientName: "János", status: "booked" },
            { date: "2024-11-10", time: "11:00", clientName: "Katalin", status: "available" }
        ],
    },
    {
        id: 2,
        name: "Fodrász Zita",
        title: "Divat és fodrász szakon végzett szakember",
        description: "Hosszú évek tapasztalatával rendelkező stylist.",
        workingHours: [
            { day: "Péntek", dayIndex: 5, start: "12:00", end: "18:00" },
            { day: "Szombat", dayIndex: 6, start: "08:00", end: "14:00" },
        ],
        bookings: [
            { date: "2024-11-10", time: "10:00", clientName: "János", status: "booked" },
            { date: "2024-11-10", time: "11:00", clientName: "Katalin", status: "available" }
        ]
    },
];



// Interface definitions
type WorkingHours = {
    day: string;
    dayIndex: number;
    start: string;
    end: string;
}

type BookingStatus = "available" | "booked";
type Booking = {
    date: string;
    time: string;
    clientName: string;
    status: BookingStatus;
}

type Hairdresser = {
    id: number;
    name: string;
    title: string;
    description: string;
    workingHours: WorkingHours[];
    bookings: Booking[];
}


export class HairdresserPerson {

    public hairdresserData: Hairdresser;
    public constructor(id: number, name: string, title: string, description: string, workingHours: WorkingHours[], bookings: Booking[]) {
        this.hairdresserData = {
            id: id,
            name: name,
            title: title,
            description: description,
            workingHours: workingHours,
            bookings: bookings
        }
    }
}

export class Hairdressers {

    public hairdressersData: HairdresserPerson[];
    public constructor() {
        this.hairdressersData = [];
        appointmentsData.forEach(item => {
            this.hairdressersData.push(new HairdresserPerson(
                item.id,
                item.name,
                item.title,
                item.description,
                item.workingHours as WorkingHours[],
                item.bookings as Booking[]
            ));
        });
    }

    public getHairDresserPerson(): HairdresserPerson[] {
        return this.hairdressersData;
    }
}

const hairSalon = new Hairdressers();


// Fetch hairdresser data from localStorage or use a default array if not available
// const hairSalon: Hairdresser[] = JSON.parse(localStorage.getItem("bookings") || "[]");

// Function to display all bookings for each hairdresser
function displayBookings() {
    const container = document.getElementById("bookingsContainer");

    if (container) {
        container.innerHTML = ""; // Clear any existing content

        if (hairSalon.hairdressersData.length === 0) {
            container.innerHTML = "<p>Nincsenek elérhető foglalások.</p>";
            return;
        }

        hairSalon.hairdressersData.forEach(hairdresser => {
            const section = document.createElement("section");
            section.className = "hairdresser-section";
            section.innerHTML = `
                <h2>${hairdresser.hairdresserData.name}</h2>
                <p>${hairdresser.hairdresserData.title}</p>
                <p>${hairdresser.hairdresserData.description}</p>
            `;

            if (hairdresser.hairdresserData.bookings.length > 0) {
                const bookingList = document.createElement("ul");
                hairdresser.hairdresserData.bookings.forEach(booking => {
                    const listItem = document.createElement("li");
                    listItem.innerHTML = `
                        <strong>Dátum:</strong> ${booking.date} | 
                        <strong>Időpont:</strong> ${booking.time} | 
                        <strong>Vendég:</strong> ${booking.clientName}
                    `;
                    bookingList.appendChild(listItem);
                });
                section.appendChild(bookingList);
            } else {
                section.innerHTML += "<p>Nincsenek foglalások.</p>";
            }

            container.appendChild(section);
        });
    }
}

// Load and display bookings when the admin page is loaded
document.addEventListener("DOMContentLoaded", () => {
    displayBookings();
});
