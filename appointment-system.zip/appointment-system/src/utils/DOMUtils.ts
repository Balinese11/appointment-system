export class DOMUtils {
    public static displayConfirmation(message: string, type: "success" | "error" = "success"): void {
        const confirmationMessage = document.getElementById("confirmation-message")!;
        confirmationMessage.textContent = message;
        confirmationMessage.className = `confirmation-message ${type}`;
        confirmationMessage.style.display = "block";
        setTimeout(() => {
            confirmationMessage.style.display = "none";
        }, 5000);
    }
}
