
export interface Hairdresser {
    id: number;
    name: string;
    title: string;
    description: string;
    workingHours: {
      day: string;
      dayIndex: number;
      start: string;
      end: string;
    }[];
    bookings: {
      date: string;
      time: string;
      clientName: string;
      status: "booked" | "available";
    }[];
  }
  

export class HairdresserPerson {
    constructor(public hairdresserData: Hairdresser) {}
}
