export type BookingStatus = "available" | "booked";

export type Booking = {
    date: string;
    time: string;
    clientName: string;
    status: BookingStatus;
};
