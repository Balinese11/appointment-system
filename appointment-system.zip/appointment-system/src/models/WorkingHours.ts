export type WorkingHours = {
    day: string;
    dayIndex: number;
    start: string;
    end: string;
};
