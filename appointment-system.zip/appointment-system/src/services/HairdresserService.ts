import { appointmentsData } from "../data/appointmentsData";
import { HairdresserPerson } from "../models/Hairdresser";

export class HairdresserService {
    private hairdressersData: HairdresserPerson[] = [];

    constructor() {
        this.hairdressersData = appointmentsData.map(
            (data) => new HairdresserPerson(data)
        );
    }

    public getHairdressers(): HairdresserPerson[] {
        return this.hairdressersData;
    }

    public findHairdresserById(id: number): HairdresserPerson | undefined {
        return this.hairdressersData.find(
            (hairdresser) => hairdresser.hairdresserData.id === id
        );
    }
}
