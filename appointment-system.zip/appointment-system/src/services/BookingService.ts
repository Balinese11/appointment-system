import { Booking } from "../models/Booking";
import { HairdresserPerson } from "../models/Hairdresser";

export class BookingService {
    public addBooking(
        hairdresser: HairdresserPerson,
        booking: Booking
    ): void {
        hairdresser.hairdresserData.bookings.push(booking);
        localStorage.setItem(
            `bookings_${hairdresser.hairdresserData.id}`,
            JSON.stringify(hairdresser.hairdresserData.bookings)
        );
    }
}
