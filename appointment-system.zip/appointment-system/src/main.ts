import { HairdresserService } from "./services/HairdresserService";
import { BookingService } from "./services/BookingService";
import { DOMUtils } from "./utils/DOMUtils";

const hairdresserService = new HairdresserService();
const bookingService = new BookingService();

let selectedHairdresserId: number | null = null;
let selectedDate: string | null = null;
let selectedTime: string | null = null;

function openModal(hairdresserId: number): void {
    selectedHairdresserId = hairdresserId;
    const modal = document.getElementById("hairdresserModal");
    if (modal) modal.style.display = "flex";
}

function closeModal(): void {
    const modal = document.getElementById("hairdresserModal");
    if (modal) modal.style.display = "none";
    selectedDate = null;
    selectedTime = null;
}

function confirmBooking(): void {
    if (selectedHairdresserId && selectedDate && selectedTime) {
        const hairdresser = hairdresserService.findHairdresserById(selectedHairdresserId);
        if (hairdresser) {
            bookingService.addBooking(hairdresser, {
                date: selectedDate,
                time: selectedTime,
                clientName: "User",
                status: "booked"
            });
            DOMUtils.displayConfirmation("Foglalás sikeresen létrejött!");
            closeModal();
        }
    } else {
        DOMUtils.displayConfirmation("Hiányzó információk!", "error");
    }
}

function init(): void {
    document.querySelectorAll(".book-appointment-button").forEach((button) => {
        button.addEventListener("click", (event) => {
            const target = event.target as HTMLElement;
            const id = target.getAttribute("data-hairdresser-id");
            if (id) openModal(Number(id));
        });
    });

    document.getElementById("closeModal")?.addEventListener("click", closeModal);
    document.getElementById("submit-button")?.addEventListener("click", confirmBooking);
}

init();
