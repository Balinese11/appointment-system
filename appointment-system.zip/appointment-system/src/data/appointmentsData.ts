import { Hairdresser } from "../models/Hairdresser";

export const appointmentsData: Hairdresser[] = [
  {
    id: 0,
    name: "Fodrász Fruzsi",
    title: "Mesterfodrász",
    description: "20 éves tapasztalattal és modern stílusérzékkel rendelkező fodrász.",
    workingHours: [
      {
        day: "Hétfő",
        dayIndex: 1,
        start: "10:00",
        end: "15:30",
      },
      {
        day: "Szerda",
        dayIndex: 3,
        start: "09:00",
        end: "14:30",
      },
      {
        day: "Szombat",
        dayIndex: 6,
        start: "10:00",
        end: "13:00",
      },
    ],
    bookings: [
      {
        date: "2024-11-16",
        time: "10:00",
        clientName: "János",
        status: "booked",
      },
      {
        date: "2024-11-17",
        time: "11:00",
        clientName: "Katalin",
        status: "available",
      },
    ],
  },
  {
    id: 1,
    name: "Fodrász Bence",
    title: "Stílustanácsadó és fodrász",
    description: "A legújabb trendekkel, férfi és női hajvágások specialistája.",
    workingHours: [
      {
        day: "Kedd",
        dayIndex: 2,
        start: "11:00",
        end: "18:00",
      },
      {
        day: "Csütörtök",
        dayIndex: 4,
        start: "10:00",
        end: "16:00",
      },
    ],
    bookings: [
      {
        date: "2024-11-10",
        time: "10:00",
        clientName: "János",
        status: "booked",
      },
      {
        date: "2024-11-10",
        time: "11:00",
        clientName: "Katalin",
        status: "available",
      },
    ],
  },
  {
    id: 2,
    name: "Fodrász Zita",
    title: "Divat és fodrász szakon végzett szakember",
    description: "Hosszú évek tapasztalatával rendelkező stylist.",
    workingHours: [
      {
        day: "Péntek",
        dayIndex: 5,
        start: "12:00",
        end: "18:00",
      },
      {
        day: "Szombat",
        dayIndex: 6,
        start: "08:00",
        end: "14:00",
      },
    ],
    bookings: [
      {
        date: "2024-11-10",
        time: "10:00",
        clientName: "János",
        status: "booked",
      },
      {
        date: "2024-11-10",
        time: "11:00",
        clientName: "Katalin",
        status: "available",
      },
    ],
  },
];
