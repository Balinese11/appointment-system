"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const HairdresserService_1 = require("../build/services/HairdresserService");
const BookingService_1 = require("../build/services/BookingService");
const DOMUtils_1 = require("../build/utils/DOMUtils");
const hairdresserService = new HairdresserService_1.HairdresserService();
const bookingService = new BookingService_1.BookingService();
let selectedHairdresserId = null;
let selectedDate = null;
let selectedTime = null;
function openModal(hairdresserId) {
    selectedHairdresserId = hairdresserId;
    const modal = document.getElementById("hairdresserModal");
    if (modal)
        modal.style.display = "flex";
}
function closeModal() {
    const modal = document.getElementById("hairdresserModal");
    if (modal)
        modal.style.display = "none";
    selectedDate = null;
    selectedTime = null;
}
function confirmBooking() {
    if (selectedHairdresserId && selectedDate && selectedTime) {
        const hairdresser = hairdresserService.findHairdresserById(selectedHairdresserId);
        if (hairdresser) {
            bookingService.addBooking(hairdresser, {
                date: selectedDate,
                time: selectedTime,
                clientName: "User",
                status: "booked"
            });
            DOMUtils_1.DOMUtils.displayConfirmation("Foglalás sikeresen létrejött!");
            closeModal();
        }
    }
    else {
        DOMUtils_1.DOMUtils.displayConfirmation("Hiányzó információk!", "error");
    }
}
function init() {
    document.querySelectorAll(".book-appointment-button").forEach((button) => {
        button.addEventListener("click", (event) => {
            const target = event.target;
            const id = target.getAttribute("data-hairdresser-id");
            if (id)
                openModal(Number(id));
        });
    });
    document.getElementById("closeModal")?.addEventListener("click", closeModal);
    document.getElementById("submit-button")?.addEventListener("click", confirmBooking);
}
init();
//# sourceMappingURL=main.js.map